# [[REDE PETITE GALERIE]]

****

Trabalho realizado por Laura Manganote para o Programa de Formação em Pesquisa do Instituto de Arte Contemporânea (IAC), com orientação de Galciani Neves.

---

# O PROJETO

Em *[[Rede Petite Galerie]],* as fotografias das *vernissages* realizadas na galeria carioca se ramificam nas constelações de sujeitos, territórios, instituições e exposições que a estruturaram como nódulo central dos circuitos-sistemas institucionalizantes do mercado de arte no Brasil entre as décadas de 1950 e 1980. Unindo objeto e prática de pesquisa, o trabalho se desvela como uma tradução visual do mapa de relações que orbitaram a Petite Galerie e, ao mesmo tempo, uma plataforma de continuação à pesquisa no acervo. Foi criado a partir da coleta de metadados presentes nas imagens pesquisadas, usando de informações das biografias canônicas dos artistas à elas relacionados, disponíveis em seus sites oficiais e em enciclopédias online de difusão cultural. Com isso, foram identificadas conexões entre os elementos que circundam 15 fotografias do arquivo da Petite Galerie, construtivas para a compreensão de relações fundantes do sistema artístico brasileiro e para a realização de novas pesquisas.

**O projeto pode ser acessado através de um [mapa interativo online](https://lauramanganote.com/rede-petite-galerie/) e da plataforma digital Obsidian, onde os arquivos disponíveis para download podem ser editados para continuação coletiva da pesquisa.**

---

# PROJETO ONLINE

Na plataforma online, é possível navegar pelo mapa de relações construído a partir desta pesquisa. Nele, estão disponíveis para acesso os pontos no mapa que representam os arquivos aqui estudados, linkados à notas com as biografias utilizadas para a seleção dos metadados que orbitam os sujeitos presentes nas imagens. Uma vez clicados, os pontos com códigos de referência devem te direcionar para as mesmas páginas disponíveis abaixo, na seção “Os arquivos”. 

Esta mesma página, é o banco de dados do nosso projeto. Todos as subpáginas aqui citadas formam pontos no mapa digital, incluindo a que estamos agora. Ao clicar no ponto [[ REDE PETITE GALERIE ]], você retorna para esta página inicial. Este sistema foi criado a partir do projeto open source disponível em: https://github.com/manganote/notion-graph-view

Essa versão do projeto permite a visualização pelo navegador da pesquisa aqui realizada. 

![Captura de tela 2024-09-24 115730.png](Captura_de_tela_2024-09-24_115730.png)

printscreen do mapa online criado para o projeto, disponível em: [https://lauramanganote.com/rede-petite-galerie/](https://lauramanganote.com/rede-petite-galerie/)

---

# PROJETO COLETIVO

Na plataforma Obsidian, é possível trabalhar com as conexões aqui desenhadas para continuação de pesquisas sobre a Petite Galerie e outros assuntos que podem utilizar das relações aparentes no mapa. O programa é a plataforma de anotação utilizada pela pesquisadora para o desenvolvimento da pesquisa, sendo um software gratuito para criação de notas com hiperlinks. Com ele instalado, será possível acessar as notas criadas ao longo da pesquisa sobre as 15 fotografias estudadas, onde estão disponíveis as biografias que explicitam os metadados aparentes no mapa de relações. 

Neste caso, todos os pontos do mapa são clicáveis. Como no mapa digital, apenas os arquivos com código de referência já possuem notas com hiperlinks, mas, nessa versão, é possível adicionar novas notas e pontos no mapa de relações. Ao clicar em um ponto que ainda não possui uma nota com suas próprias conexões, uma nova página será gerada, onde é possível continuar a expansão do mapa aqui disponível individualmente em sua própria plataforma. 

Uma vez baixado, o mapa pode ser alterado no Obsidian por cada um sem interferência na utilização de outros, funcionando apenas como um ponto de partida para outras pesquisas que pode ser expandido de forma individual de acordo com o contexto. 

![Captura de tela 2024-09-24 141225.png](Captura_de_tela_2024-09-24_141225.png)

***Para usar do projeto para sua própria pesquisa, você vai precisar:***

- [ ]  Baixar a plataforma Obsidian
    
    [Acesso para o Download](https://obsidian.md/download)
    
    [Tutorial](https://publish.obsidian.md/help-pt-br/Come%C3%A7ando/Baixe+e+instale+o+Obsidian)
    

- [ ]  Baixar a pasta com os arquivos do projeto. Essa pasta funcionará como um “cofre” ou “vault” do conjunto de notas na sua plataforma, que armanezará as já existentes e as notas que forem criadas posteriomente.
    
    [https://www.notion.so](https://www.notion.so)
    

- [ ]  Configurar a pasta baixada como um cofre (vault) do seu Obsidian. Na primeira vez que abrir o Obsidian, você será solicitado a adicionar um novo cofre. Nesta etapa, você deve clicar em “Abrir pasta como cofre” e selecionar a pasta [[ Rede Petite Galerie ]].

Uma vez feito isso, todas as notas usadas para a criação do mapa de relações estarão disponíveis no seu computador, contendo as fotografias que foram estudadas e as biografias selecionadas para a coleta de metadados. 

---

# OS ARQUIVOS

[Arquivos](Arquivos%20cccff91c270f4d929a414d734858ef41.csv)

# SAIBA MAIS

O período entre as décadas de 1950 e 1980 é marcado por intensas transformações políticas, sociais e culturais no contexto social brasileiro. No campo das artes, abarca o momento de institucionalização da arte no país, de emergência das neovanguardas pós-modernistas, do estabelecimento do mercado de arte no sudeste e da criação dos centros culturais na região. Nesse contexto, a Petite Galerie foi um espaço central de impulsionamento dessas transformações, com uma programação de exposições e atividades culturais diversas e com a participação de artistas emergentes e de movimentos artísticos variados em seus eventos. Teve participação ativa na consolidação do mercado artístico no Rio de Janeiro a partir do estabelecimento da prática de financiamento nos leilões de arte e no fortalecimento dos diferentes movimentos vanguardistas que despontaram em todas as suas décadas de funcionamento (1950-1980).

A galeria se tornou um polo medular da rede de pessoas e relações que construíram o sistema artístico no Rio de Janeiro, personificada na figura do seu sócio principal e responsável pela programação, Franco Terranova. Em volta dele, orbitavam empresários, colecionadores, artistas, críticos de arte, amigos, familiares, que também representavam grande parte do público que frequentava a Petite Galerie e os outros lugares que a circundavam. Ela teve três endereços no Rio de Janeiro: Av. Atlântica, 2964 - Copacabana; Praça General Osório, 53 - Ipanema; Rua Barão da Torre, 220 - Ipanema. Em São Paulo, abriu um espaço na Av. Paulista, 1731 - Bela Vista e na Rua Haddock Lobo, 1397 - Cerqueira César. Para a realização de leilões, ocupava rotineiramente o Copacabana Palace, em frente a praia mais famosa do Rio de Janeiro. Vinculado a esses territórios, estavam os espectadores-consumidores de arte moderna que fomentaram a circulação do mercado artístico e alicerçaram a experiência do indivíduo moderno nas grandes metrópoles brasileiras.

Em algumas fotografias encontradas no arquivo da Petite Galerie, do IAC - Instituto de Arte Contemporânea (São Paulo), seus rostos são identificáveis - entre eles, estão os de Stella Goulart Marinho, Juracy Magalhães, Burle Marx, Lygia Clark, Heitor dos Prazeres, Guignard, Portinari, Gastão Henrique Manoel, Maria Leontina, Mestre Guarany, Jorge Amado, Tomie Ohtake, Antônio Manuel, Agnaldo dos Santos, Mário Pedrosa, Antonio Bandeira.

Com esses sujeitos e territórios em mente, identificados a partir das fotografias de exposições presentes no acervo estudado, identifica-se como a galeria é, ao mesmo tempo, a representação de um sistema artístico que se consolidou a partir de uma série de relações que orbitaram os diferentes endereços da Petite Galerie e uma plataforma de circulação ideológica que fomentou a consolidação das vanguardas pós-modernistas no Brasil e suas conexões com o mercado de arte. As exposições registradas podem ser entendidas como um ponto de encontro dessa rede, que, quando compreendida como tal, revela como a predominância da galeria no mercado artístico brasileiro entre 1960 e 1970 partiu do estabelecimento rizomático de relações em círculos artísticos variados e, muitas vezes, opostos.

Para materializar os processos e resultados que se desdobraram dos arquivos e da própria experiência de pesquisa, este projeto propõe unir esta tradução da Petite Galerie com as práticas artístico-arquivísticas da autora, que partem da sistematização visual de ideais e imagens. Assim, tendo como base as fotografias das exposições que aconteceram na galeria, representações dos indivíduos e lugares que corporificaram e territorializaram a Petite Galerie, construimos um mapa-constelação das relações entre os sujeitos e territórios que a estruturaram como nódulo central dos circuitos-sistemas institucionalizantes do mercado de arte no Brasil. 

Em conjunto, estão disponíveis notas textuais vinculadas aos arquivos que explicitam as relações dos seus componentes, evidenciando a criação dos hiperlinks que retroalimentam o mapa proposto. Seus componentes foram identificados nas imagens, que ainda estão em fase inicial de catalogação no IAC, e, a partir das suas biografias e definições básicas, coletadas nos sites oficiais dos artistas e na bibliografia dedicada à galeria, organizados como parte de um fluxo de informações. São usadas como referências as obras de arte de [Mark Lombardi](https://www.moma.org/artists/22980) e [Josh On](https://theyrule.net/) e os pensamentos de Jacques Derrida, Gilles Deleuze e Félix Guattari para elaborar visualmente e conceitualmente a pesquisa, que se preocupa, fundamentalmente, não com os agentes identificados de forma individual, mas com suas conexões e o que elas dão a ver sobre a Petite Galerie. 

Desta maneira, construimos uma tradução visual da rede de circulação e distribuição da galeria mediada pela memória derivante de seus arquivos, revelando sua participação na institucionalização da arte e do mercado artístico brasileiro.

# OUTROS PROJETOS COMO ESSE

Esse projeto se integra à um esforço coletivo internacional de repensar as formas de visualização de dados para pensar em narrativas alternativas. 

No site abaixo, é possível encontrar a rede de pesquisadores que estão conectados à nós a partir desta pesquisa. 

[Alternative narratives visualization archive](https://alternative-narratives-vis-archive.com/)

[volte para ou acesse o mapa online](https://lauramanganote.com/rede-petite-galerie/)