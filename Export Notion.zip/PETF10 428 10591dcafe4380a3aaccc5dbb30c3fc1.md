# PETF10/428

![50037.jpg](50037.jpg)

<aside>
📎

**DESCRIÇÃO DA OBRA**

Fundo/Coleção: **Fundo Petite Galerie**

Descrição: **Registro fotográfico do artista Heitor dos Prazeres ao lado de uma mulher, enquanto toca um pandeiro.**

Número de Ordem: **50037**

Número de Registro: **PETF10/428**

**INFORMAÇÕES TÉCNICAS**

Dimensão: **18x23,9**

Duração: **0 (Valor em minutos)**

Documento: **fotografia**

Suporte: **papel fotográfico**

Matéria Técnica de Registro: **impressão**

Data de Produção: **s/d**

**Fonte: Instituto de Arte Contemporânea - IAC - Fundo: Petite Galerie**

</aside>

> Obra de [Heitor dos Prazeres](Heitor%20dos%20Prazeres%2010591dcafe4380ddb08ede684e06e98c.md) posicionada em meio a um músico e uma mulher. A fotografia parece ter sido tirada na primeira sede da [Petite Galerie](Petite%20Galerie%20d18196ba97ce424a9b80bae2696f7df4.md), na [Avenida Atlântica](Avenida%20Atla%CC%82ntica%2005d5d24267a5442b8898ed4d9733d8bd.md), considerando os aspectos arquitetônicos aparentes na imagem.
> 

“

**HEITOR DOS PRAZERES** ([Rio de Janeiro](Rio%20de%20Janeiro%20e7476ab243c54bc08d9ad434f2bc3689.md), 23 de setembro de 1898 — Rio de Janeiro, 4 de outubro de 1966) foi um compositor, cantor e pintor brasileiro. Foi um dos pioneiros na composição dos sambas e participou da fundação das primeiras escolas de samba do Brasil.

Considerado um multiartista, Heitor soube percorrer diversas linguagens, e no auge de sua produção em pintura chegou a manter um ateliê em que contava com diversos assistentes, trabalhando em um esquema de oficina. Seu ofício foi, nesse sentido, uma prática compartilhada, mas a ele competia a elaboração das composições e as principais escolhas dos gestos, bem como o detalhamento das figuras representadas.

Prazeres foi um autodidata, e sua inserção no ambiente artístico carioca foi a princípio pela via da música. Nasceu em uma família profundamente ligada a essa expressão, seu pai era clarinetista e seu tio [Hilário Jovino Ferreira](Hila%CC%81rio%20Jovino%20Ferreira%207416ce35e7ad48219794163eb695f676.md) foi um dos integrantes da primeira geração do samba urbano. Desde jovem, convive com músicos como [Donga](Donga%2010591dcafe4380eaa312c05870cd42fa.md), [João da Baiana](Joa%CC%83o%20da%20Baiana%200ef2dc2582e04ecca9816f32ce2018df.md), [Sinhô](Sinho%CC%82%2010591dcafe43807aba2fdb60602d1f9d.md), [Caninha](Caninha%2010591dcafe4380cabd3cd7a04c39e16b.md), [Pixinguinha](Pixinguinha%202195512ef1754a68a46fd4046d4cd981.md) e [Paulo da Portela](Paulo%20da%20Portela%2010591dcafe43808d8a13e155e5674ca9.md)  que frequentavam a casa de suas tias, [Tia Ciata](Tia%20Ciata%2010591dcafe4380109898e4a4854922ce.md) e [Tia Esther](Tia%20Esther%2010591dcafe4380ad89faf9da4b9291e0.md). Na década de 1930, forma o [Grupo Carioca](Grupo%20Carioca%2010591dcafe43809891f5fa39e20e153e.md) e torna-se ritmista da [Rádio Nacional](Ra%CC%81dio%20Nacional%2010591dcafe4380c7b1ead534c2a04efc.md) e do [Cassino da Urca](Cassino%20da%20Urca%2010591dcafe4380cfb807f9452d7bd4ff.md). Suas canções e composições mais populares foram: Cantar para Não Chorar, com [Paulo Portela](Paulo%20Portela%204d1b9c3e16a34fefb04af61313b2845d.md); Carioca Boêmio, Consideração, composta em parceria com [Cartola](Cartola%2010591dcafe43804580e3edfdb96749b2.md) e Pierrot Apaixonado, com [Noel Rosa](Noel%20Rosa%200a38de69872a49bf852eb6d6525ee867.md).

Na segunda metade dos anos 1930, passa a se dedicar também à pintura, tratando de temas relacionados às tradições e à cultura popular brasileira e cenas do cotidiano das populações negras da cidade. O samba, o carnaval, as paisagens urbanas e brincadeiras infantis foram seus temas mais frequentes, além disso, enfocou de modo consistente as tradições religiosas do candomblé e da umbanda.

Chega a retratar-se em diversas obras, e parte de seus personagens foram figuras de seu convívio, muito respeitados na região entre a [Cidade Nova](Cidade%20Nova%2010591dcafe4380aead76e4977e150d4d.md) e o [Cais do Porto](Cais%20do%20Porto%2010591dcafe43805ca8e7e4b480b0a228.md) do Rio de Janeiro, espaço conhecido como a “[Pequena África](Pequena%20A%CC%81frica%2010591dcafe438056aff2cd65e49bdc9e.md)”. O próprio Heitor do Prazeres, contribui, de forma decisiva para tornar essa região conhecida como um dos espaços mais efervescentes da criatividade afro-diaspórica.

Suas primeiras telas foram produzidas em 1937. Em 1951, ganha o terceiro lugar na premiação para artistas nacionais na 1a [Bienal de São Paulo](Bienal%20de%20Sa%CC%83o%20Paulo%20f19fb23b1d5342f88489a03d33f11fb8.md), com a pintura “Moenda”, que atualmente integra o acervo do [Museu de Arte Contemporânea da USP](Museu%20de%20Arte%20Contempora%CC%82nea%20da%20USP%2010591dcafe4380379a71e617a66daf69.md). Ganha uma sala especial na 2a Bienal Internacional de São Paulo em 1953, e participa das edições de 1961 e 1979. Em 1966, participa do Primeiro Festival Mundial de Artes Negras, em Dakar, Senegal, ao lado de [Agnaldo dos Santos](Agnaldo%20dos%20Santos%2010591dcafe4380468dcfdfde9056df34.md) e [Rubem Valentim](Rubem%20Valentim%20f0be19ac584747c8a5690b46c1d672bf.md). Cria cenários e figurinos para o Balé do IV Centenário da Cidade de São Paulo. Em 1999, é realizada uma mostra retrospectiva de seu trabalho no [Espaço BNDES](Espac%CC%A7o%20BNDES%2010591dcafe438037bc29e0dcec17d5c6.md) e no [Museu Nacional de Belas Artes](Museu%20Nacional%20de%20Belas%20Artes%2010291dcafe438010ad7cc84824710bb8.md) (MNBA), em homenagem ao seu centenário. Em 2023, uma grande retrospectiva de sua obra foi apresentada no [CCBB Rio de Janeiro](CCBB%20Rio%20de%20Janeiro%2010591dcafe438040905df54c249ea7f5.md). Ao longo de sua carreira artística realizou seis exposições individuais e mais de 30 mostras coletivas.

“

Fonte: [https://www.almeidaedale.com.br/pt/artistas/heitor-dos-prazeres](https://www.almeidaedale.com.br/pt/artistas/heitor-dos-prazeres)